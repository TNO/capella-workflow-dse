3D Reconstruction Example
-------------------------
- Double click on the .aird file

- Folder "Representations per category" contains:
  * Common > Functional Chain Description: 3 logical functional chain descriptions [LFCD]
     [LFCD] 1. Acquire 2D Image contains hints on viewing and simulation
  * Logical Architecture > Logical Data Flow Blank: 3 functional chains
  * Logical Architecture > Logical Function Breakdown: hierarchy of logical functions
  * EPBS architecture > Configuration Items Breakdown: diagram with 4 configuration items
  
- To apply design space exploration to a functional chain description:
  * right click on it (e.g. on [LFCD] 00. 3D- Reconstruction
  * select Workflow DSE:Run
  * in the pop-up application:
    - (ranges of) PVMT values can be chosen 
    - a simulation can be started
    - simulation results can be found in folder "gen > dse > run ..."
      double clicking on trace.etf shows a Gantt chart view

[LFCD] 1. Acquire 2D Image also contains manual steps to run a single simulation.

More details can be found in the tutorial.